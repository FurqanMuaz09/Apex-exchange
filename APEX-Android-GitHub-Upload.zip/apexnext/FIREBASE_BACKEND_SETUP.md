# APEX Profile + KYC backend setup

This build adds Firebase Firestore profile sync and private Firebase Storage upload for KYC documents. The Firebase project must be configured before cloud features work.

## One-time Firebase setup
1. Open Firebase Console for project `apexexchange-b5467`.
2. Build > Firestore Database > Create database. Choose production mode and an appropriate region.
3. Build > Storage > Get started; ensure billing/plan requirements for Storage are met for your project.
4. In Firestore Rules, publish the contents of `firestore.rules`.
5. In Storage Rules, publish the contents of `storage.rules`.
6. Confirm Authentication > Sign-in method has the providers you actually use enabled.
7. Rebuild the Android APK from GitHub Actions and test using a non-sensitive test account and dummy images first.

## What works after setup
- UID is derived from the signed-in Firebase Auth UID and remains stable for that account.
- Profile fields are saved locally and synced to `users/{Firebase UID}` in Firestore.
- KYC front/back/selfie images (max 5 MB each) are uploaded under a private per-user Storage path.
- KYC request is saved as `kycSubmissions/{Firebase UID}` with status `Pending review`.
- Password reset, email verification, sign-out use Firebase Authentication.

## Important limitations
- `Pending review` is not approval. APEX still needs a secure staff/admin review process or a compliant KYC provider. Do not manually mark users verified based only on uploaded files.
- These starter rules intentionally let a user read their own submission only and prevent user-side updates/deletes. Staff approval should be implemented through a trusted server/admin SDK with admin authentication, not by weakening client rules.
- Before collecting real CNIC/passport/selfie data, publish a privacy policy, define retention/deletion procedures, restrict staff access, and confirm applicable laws. Test with dummy documents first.
- This does not implement real deposits, withdrawals, balances, trading execution, or a regulated exchange backend.
- If Firestore/Storage has not been enabled or rules are not published, cloud saves/uploads will fail and the app will show an error; local profile copy may still be saved.
