const express = require('express');
const cors = require('cors');
const crypto = require('crypto');

const app = express();
app.disable('x-powered-by');
app.use(cors()); // Restrict allowed origins before public production deployment.
app.use(express.json({ limit: '8kb' }));
const PORT = process.env.PORT || 3000;
const KEY = (process.env.BINANCE_TESTNET_API_KEY || '').trim();
const SECRET = (process.env.BINANCE_TESTNET_API_SECRET || '').trim();
const BASE = 'https://testnet.binance.vision';

app.get('/', (_req, res) => res.json({
  service: 'APEX Binance Testnet Backend',
  mode: 'TESTNET ONLY',
  configured: Boolean(KEY && SECRET),
  accountCheckAvailable: true,
  orderPlacement: 'DISABLED_PENDING_AUTH_AND_SAFEGUARDS'
}));
app.get('/health', (_req, res) => res.json({ ok: true }));

async function signedRequest(path) {
  if (!KEY || !SECRET) throw new Error('Testnet API keys are not configured on the server.');
  const query = new URLSearchParams({ timestamp: String(Date.now()), recvWindow: '5000' }).toString();
  const signature = crypto.createHmac('sha256', SECRET).update(query).digest('hex');
  const response = await fetch(`${BASE}${path}?${query}&signature=${signature}`, {
    method: 'GET', headers: { 'X-MBX-APIKEY': KEY }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.msg || 'Binance Testnet request failed');
    error.status = response.status;
    error.binanceCode = data.code;
    throw error;
  }
  return data;
}

app.get('/api/account', async (_req, res) => {
  try {
    const account = await signedRequest('/api/v3/account');
    res.json({ mode: 'TESTNET ONLY', canTrade: account.canTrade,
      balances: (account.balances || []).filter(x => Number(x.free) > 0 || Number(x.locked) > 0) });
  } catch (e) {
    // Never return keys or signatures to the client.
    res.status(400).json({ error: e.message, binanceCode: e.binanceCode ?? null });
  }
});

// Deliberately disabled: a public unauthenticated order endpoint is unsafe.
app.post('/api/order', (_req, res) => res.status(501).json({
  error: 'Order placement is disabled until user authentication, ownership checks, rate limits, order validation, and audit logging are implemented.',
  mode: 'TESTNET ONLY'
}));

app.listen(PORT, '0.0.0.0', () => console.log(`APEX Testnet backend listening on port ${PORT}`));
