# APEX Firebase backend setup

This client code writes profile/KYC metadata to Cloud Firestore and uploads KYC images to Firebase Storage. These features do not work until the services and rules are deployed in project `apexexchange-b5467`.

1. Open Firebase Console → project `apexexchange-b5467`.
2. Build → Firestore Database → Create database. Choose production mode and an appropriate region.
3. Build → Storage → Get started; enable billing if Firebase requires it for your project/region.
4. Firestore → Rules: publish the contents of `firestore.rules`. Storage → Rules: publish `storage.rules`. Do not use public read/write rules.
5. Authentication → Sign-in method: ensure the same Email/Password and Google methods already used by the app remain enabled.
6. Rebuild APK through GitHub Actions, install, sign in, save a profile, then test KYC using dummy images first.
7. In Firestore, each account's data is stored at `users/{Firebase Auth UID}`. Files are private under `kyc/{Firebase Auth UID}/`. KYC status starts as `Pending review`; approval must be performed by a trusted admin/provider, not by the client.

## Security and production notes
- Firebase web config/API key is not a secret; security relies on Authentication and rules. Never place service-account credentials in the APK or repository.
- These starter rules let a user write their own profile document, so they are suitable for prototype testing, not final regulated-exchange deployment. Before production, split user-editable profile fields from KYC review fields and enforce status immutability using trusted server code/Cloud Functions; only a server-side admin role/provider should approve or reject KYC.
- This is not an identity verification provider. It stores submissions for review; it does not validate CNIC authenticity or perform face matching. Obtain legal/privacy review before collecting real identity documents.
