const assets=[{sym:'BTC',name:'Bitcoin',price:null,change:null,icon:'₿',cls:'btc'},{sym:'ETH',name:'Ethereum',price:null,change:null,icon:'◆',cls:'eth'},{sym:'BNB',name:'BNB',price:null,change:null,icon:'◆',cls:'bnb'},{sym:'SOL',name:'Solana',price:null,change:null,icon:'◎',cls:'sol'},{sym:'XRP',name:'XRP',price:null,change:null,icon:'✕',cls:'generic'},{sym:'USDT',name:'Tether',price:null,change:null,icon:'₮',cls:'usdt'},{sym:'DOGE',name:'Dogecoin',price:null,change:null,icon:'Ð',cls:'generic'},{sym:'ADA',name:'Cardano',price:null,change:null,icon:'A',cls:'generic'},{sym:'TRX',name:'TRON',price:null,change:null,icon:'T',cls:'generic'},{sym:'LINK',name:'Chainlink',price:null,change:null,icon:'⬡',cls:'generic'}];let filter='All',mktFilter='All',orderSide='Buy',balanceVisible=true,currentPair='BTC',chartInterval='1h';const $=s=>document.querySelector(s);const money=n=>n<1?n.toFixed(4):n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});function row(a){const ready=Number.isFinite(a.price),change=Number.isFinite(a.change)?a.change:0;return `<button class="market-row" type="button" data-sym="${a.sym}" data-change="${change}"><span class="coin ${a.cls}">${a.icon}</span><div class="market-name"><b>${a.sym}/USDT</b><small>${a.name}</small></div><div class="right"><b>${ready?money(a.price):'Loading…'}</b><small>${ready?'≈ $'+money(a.price):'Waiting for API'}</small></div><span class="change ${change>=0?'up':'down'}">${ready?(change>0?'+':'')+change.toFixed(2)+'%':'—'}</span></button>`}function draw(){let home=assets.filter(a=>filter==='All'||(filter==='Gainers'?a.change>0:a.change<0));$('#homeMarkets').innerHTML=home.slice(0,5).map(row).join('');let q=($('#marketSearch')?.value||'').toLowerCase();let all=assets.filter(a=>(mktFilter==='All'||(mktFilter==='Gainers'?a.change>0:a.change<0))&&(a.sym.toLowerCase().includes(q)||a.name.toLowerCase().includes(q)));$('#allMarkets').innerHTML=all.map(row).join('')||'<p class="disclaimer">No matching assets.</p>'}async function refreshMarket(){const status=document.querySelector('.tag');try{const response=await fetch('https://api.binance.com/api/v3/ticker/24hr',{cache:'no-store'});if(!response.ok)throw new Error('Binance API HTTP '+response.status);const tickers=await response.json();const bySymbol=new Map(tickers.map(t=>[t.symbol,t]));assets.forEach(a=>{const t=bySymbol.get(a.sym+'USDT');if(t){a.price=Number(t.lastPrice);a.change=Number(t.priceChangePercent)}});['BTC','ETH','BNB'].forEach(sym=>{const t=bySymbol.get(sym+'USDT'),p=$('#ticker'+sym),c=$('#ticker'+sym+'Change');if(t&&p&&c){p.textContent=money(Number(t.lastPrice));const ch=Number(t.priceChangePercent);c.textContent=(ch>0?'+':'')+ch.toFixed(2)+'%';c.classList.toggle('negative',ch<0)}});draw();renderWallet();const ticker=bySymbol.get(currentPair+'USDT');if(ticker){$('#tradePrice').textContent=money(Number(ticker.lastPrice));$('#orderPrice').placeholder=money(Number(ticker.lastPrice));if(!$('#orderPrice').dataset.userEdited&&$('#orderType').value!=='Market')$('#orderPrice').value=Number(ticker.lastPrice).toString();const coin=assets.find(a=>a.sym===currentPair);$('#pairName').innerHTML=currentPair+'/USDT <small>'+(coin?coin.name:currentPair)+'</small>';updateTotal()}if(status){status.textContent='● Binance live';status.style.color='var(--green)'}await refreshChart()}catch(e){if(status){status.textContent='● Market API unavailable';status.style.color='var(--red)'}console.warn('Binance market API unavailable',e)}}async function refreshChart(){try{const base='https://api.binance.com/api/v3/';const [kr,dr,tr]=await Promise.all([fetch(base+'klines?symbol='+currentPair+'USDT&interval='+chartInterval+'&limit=36'),fetch(base+'depth?symbol='+currentPair+'USDT&limit=5'),fetch(base+'trades?symbol='+currentPair+'USDT&limit=5')]);if(!kr.ok)throw new Error('Kline API error');const candles=await kr.json(),depth=dr.ok?await dr.json():null,trades=tr.ok?await tr.json():null;const vals=candles.flatMap(c=>[Number(c[2]),Number(c[3])]),min=Math.min(...vals),max=Math.max(...vals),range=max-min||1,svg=$('.chart-placeholder svg');if(svg){const w=340,h=160,pad=8,step=w/candles.length;let marks='';candles.forEach((c,i)=>{const x=i*step+step/2,o=Number(c[1]),hi=Number(c[2]),lo=Number(c[3]),cl=Number(c[4]),y=v=>h-pad-(v-min)/range*(h-pad*2),color=cl>=o?'#0ecb81':'#f6465d',top=Math.min(y(o),y(cl)),body=Math.max(2,Math.abs(y(o)-y(cl)));marks+=`<line x1="${x}" y1="${y(hi)}" x2="${x}" y2="${y(lo)}" stroke="${color}" stroke-width="1"/><rect x="${x-step*.28}" y="${top}" width="${Math.max(2,step*.56)}" height="${body}" fill="${color}" rx=".5"/>`});svg.innerHTML=`<g opacity=".22" stroke="#68717e" stroke-dasharray="3 4"><path d="M0 40H340 M0 80H340 M0 120H340"/></g>${marks}`}const label=$('.chart-label span');if(label)label.textContent=currentPair+'/USDT · '+chartInterval+' · Binance candles';if(depth){const bids=$('#bids'),asks=$('#asks');bids.innerHTML=depth.bids.slice(0,5).map(x=>`<div class="book-row bid"><span>${money(Number(x[0]))}</span><span>${Number(x[1]).toFixed(4)}</span></div>`).join('');asks.innerHTML=depth.asks.slice(0,5).reverse().map(x=>`<div class="book-row ask"><span>${money(Number(x[0]))}</span><span>${Number(x[1]).toFixed(4)}</span></div>`).join('')}if(trades){$('#recentTrades').innerHTML=trades.slice(-5).reverse().map(t=>`<div class="recent-row"><span style="color:${t.isBuyerMaker?'var(--red)':'var(--green)'}">${money(Number(t.price))}</span><span>${Number(t.qty).toFixed(4)}</span><span>${new Date(Number(t.time)).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'})}</span></div>`).join('')}}catch(e){const label=$('.chart-label span');if(label)label.textContent='Chart/order book unavailable — check connection';console.warn('Binance chart data unavailable',e)}}function toast(msg){let t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2400)}function tab(name){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===name));document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.tab===name));if(name==='markets')draw();window.scrollTo({top:0,behavior:'smooth'})}document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>tab(b.dataset.tab)));document.querySelectorAll('[data-filter]').forEach(b=>b.addEventListener('click',()=>{filter=b.dataset.filter;document.querySelectorAll('[data-filter]').forEach(x=>x.classList.toggle('selected',x===b));draw()}));document.querySelectorAll('[data-mktfilter]').forEach(b=>b.addEventListener('click',()=>{mktFilter=b.dataset.mktfilter;document.querySelectorAll('[data-mktfilter]').forEach(x=>x.classList.toggle('selected',x===b));draw()}));$('#marketSearch').addEventListener('input',draw);$('#marketSearchBtn').addEventListener('click',()=>$('#marketSearch').focus());$('#searchOpen').addEventListener('click',()=>{tab('markets');$('#marketSearch').focus()});$('#hideBalance').addEventListener('click',()=>{balanceVisible=!balanceVisible;$('#balance').innerHTML=balanceVisible?'Connect account <small>USDT</small>':'•••••••• <small>USDT</small>'});document.querySelectorAll('[data-action]').forEach(b=>b.addEventListener('click',()=>toast(({deposit:'Deposit flow needs verified account and payment integration.',withdraw:'Withdrawals are disabled in this prototype.',transfer:'Internal transfers are not connected.',buy:'Buying crypto is disabled until a compliant backend is connected.'})[b.dataset.action])));document.querySelectorAll('[data-order]').forEach(b=>b.addEventListener('click',()=>{orderSide=b.dataset.order;document.querySelectorAll('[data-order]').forEach(x=>x.classList.toggle('selected',x===b));$('#placeOrder').textContent='Log in to trade';$('#placeOrder').style.background=orderSide==='Buy'?'var(--green)':'var(--red)';$('#placeOrder').style.color='#111'}));function choosePair(sym){if(sym==='USDT'){toast('Choose a tradable coin paired with USDT.');return}if(!assets.some(a=>a.sym===sym))return;currentPair=sym;$('#orderPrice').dataset.userEdited='';$('#orderPrice').value='';$('#orderPrice').placeholder='Market price';$('#orderAmount').value='';tab('trade');refreshMarket();refreshChart()}document.addEventListener('click',e=>{const r=e.target.closest('.market-row[data-sym]');if(r)choosePair(r.dataset.sym)});document.querySelectorAll('[data-interval]').forEach(b=>b.addEventListener('click',()=>{chartInterval=b.dataset.interval;document.querySelectorAll('[data-interval]').forEach(x=>x.classList.toggle('selected',x===b));refreshChart()}));$('#orderType').addEventListener('change',()=>{const market=$('#orderType').value==='Market';$('#orderPrice').disabled=market;$('#orderPrice').placeholder=market?'Uses current market price':'Enter limit price';$('#priceLabel').firstChild.textContent=market?'Price (market)':'Price (USDT)';updateTotal()});function updateTotal(){let p=parseFloat($('#orderPrice').value)||0;if($('#orderType').value==='Market'){const a=assets.find(x=>x.sym===currentPair);p=a&&Number.isFinite(a.price)?a.price:0}let a=parseFloat($('#orderAmount').value)||0;$('#orderTotal').textContent=(p*a).toLocaleString('en-US',{maximumFractionDigits:4})+' USDT'}$('#orderPrice').addEventListener('input',()=>{$('#orderPrice').dataset.userEdited='1';updateTotal()});$('#orderAmount').addEventListener('input',updateTotal);$('#placeOrder').addEventListener('click',()=>toast('Live orders are disabled. Secure Binance account integration and testnet verification are required.'));
function showAuthDialog(){
  if(document.getElementById('apexAuthOverlay')) return;
  const overlay=document.createElement('div');
  overlay.id='apexAuthOverlay';
  overlay.style.cssText='position:fixed;inset:0;z-index:9999;background:#000b;display:flex;align-items:center;justify-content:center;padding:18px;';
  overlay.innerHTML=`<section style="width:100%;max-width:390px;background:#181a20;color:#eaecef;border:1px solid #333;border-radius:18px;padding:22px;box-shadow:0 12px 40px #0008;font-family:inherit">
    <div style="display:flex;justify-content:space-between;align-items:center"><h2 style="margin:0 0 16px">APEX account</h2><button id="apexAuthClose" aria-label="Close" style="background:none;color:#fff;border:0;font-size:26px">×</button></div>
    <p style="color:#aeb4bc;font-size:13px;margin-top:0">Sign in or create an account. This does not enable deposits or trading.</p>
    <label style="display:block;font-size:13px;margin:12px 0 5px">Email</label>
    <input id="apexAuthEmail" type="email" autocomplete="email" placeholder="you@example.com" style="box-sizing:border-box;width:100%;padding:13px;border-radius:8px;border:1px solid #454a53;background:#0b0e11;color:#fff">
    <label style="display:block;font-size:13px;margin:12px 0 5px">Password</label>
    <input id="apexAuthPassword" type="password" autocomplete="current-password" placeholder="At least 6 characters" style="box-sizing:border-box;width:100%;padding:13px;border-radius:8px;border:1px solid #454a53;background:#0b0e11;color:#fff">
    <div id="apexAuthMessage" role="status" style="font-size:13px;min-height:18px;color:#f0b90b;margin:10px 0"></div>
    <button id="apexEmailSignIn" style="width:100%;padding:13px;border:0;border-radius:8px;background:#f0b90b;color:#111;font-weight:700;margin-top:4px">Log in</button>
    <button id="apexEmailSignUp" style="width:100%;padding:12px;border:1px solid #454a53;border-radius:8px;background:transparent;color:#eaecef;font-weight:600;margin-top:9px">Create account</button>
    <div style="text-align:center;color:#858c96;margin:13px 0;font-size:12px">OR</div>
    <button id="apexGoogleSignIn" style="width:100%;padding:12px;border:1px solid #454a53;border-radius:8px;background:#fff;color:#222;font-weight:700">Continue with Google</button>
  </section>`;
  document.body.appendChild(overlay);
  const msg=overlay.querySelector('#apexAuthMessage');
  const auth=window.apexAuth;
  if(auth && auth.currentUser){
    const signedInNote=document.createElement('div');
    signedInNote.style.cssText='margin:0 0 12px;padding:10px;border-radius:8px;background:#0b0e11;color:#0ecb81;font-size:13px;overflow-wrap:anywhere';
    signedInNote.textContent='Signed in as '+(auth.currentUser.email||'Google user');
    const signOut=document.createElement('button');
    signOut.type='button';
    signOut.textContent='Sign out';
    signOut.style.cssText='width:100%;padding:12px;border:1px solid #f6465d;border-radius:8px;background:transparent;color:#f6465d;font-weight:700;margin-bottom:12px';
    signOut.onclick=async()=>{
      try{await auth.signOut();msg.style.color='#0ecb81';msg.textContent='Signed out successfully';setTimeout(()=>overlay.remove(),700);}
      catch(e){msg.style.color='#f6465d';msg.textContent='Sign out failed: '+(e.code||'unknown error');}
    };
    const section=overlay.querySelector('section');
    section.insertBefore(signOut,section.children[1]);
    section.insertBefore(signedInNote,signOut);
  }
  overlay.querySelector('#apexAuthClose').onclick=()=>overlay.remove();
  overlay.addEventListener('click',e=>{if(e.target===overlay)overlay.remove()});
  function explainError(e){
    const codes={
      'auth/invalid-email':'Please enter a valid email address.',
      'auth/missing-password':'Enter your password.',
      'auth/weak-password':'Password must be at least 6 characters.',
      'auth/email-already-in-use':'An account with this email already exists.',
      'auth/invalid-credential':'Email or password is incorrect.',
      'auth/user-not-found':'No account found. Create an account first.',
      'auth/wrong-password':'Email or password is incorrect.',
      'auth/network-request-failed':'Network error. Check your internet connection.',
      'auth/operation-not-allowed':'Enable this sign-in method in Firebase Console.',
      'auth/unauthorized-domain':'Add this app domain in Firebase Authentication → Settings → Authorized domains.'
    };
    msg.textContent=codes[e && e.code] || ('Sign-in failed: '+((e && e.code)||'unknown error'));
  }
  async function run(action){
    if(!auth){msg.textContent='Firebase SDK did not load. Check internet and reload.';return}
    const email=overlay.querySelector('#apexAuthEmail').value.trim();
    const password=overlay.querySelector('#apexAuthPassword').value;
    msg.textContent='Please wait…';
    try{
      const cred=await action(email,password);
      const user=cred.user;
      msg.style.color='#0ecb81';
      msg.textContent='Signed in as '+(user.email||'Google user');
      const avatar=document.querySelector('.avatar');
      if(avatar)avatar.textContent=(user.email||'U').slice(0,1).toUpperCase();
      const login=document.querySelector('#loginBtn');
      if(login)login.textContent='Signed in';
      setTimeout(()=>overlay.remove(),1200);
    }catch(e){msg.style.color='#f6465d';explainError(e)}
  }
  overlay.querySelector('#apexEmailSignIn').onclick=()=>run((email,password)=>auth.signInWithEmailAndPassword(email,password));
  overlay.querySelector('#apexEmailSignUp').onclick=()=>run((email,password)=>auth.createUserWithEmailAndPassword(email,password));
  overlay.querySelector('#apexGoogleSignIn').onclick=async()=>{
    if(!auth){msg.textContent='Firebase SDK did not load. Check internet and reload.';return}
    try{
      msg.textContent='Opening Google sign-in…';
      const provider=new firebase.auth.GoogleAuthProvider();
      await auth.signInWithRedirect(provider);
    }catch(e){msg.style.color='#f6465d';explainError(e)}
  };
  if(auth){
    auth.getRedirectResult().then(result=>{
      if(result.user){msg.style.color='#0ecb81';msg.textContent='Signed in as '+(result.user.email||'Google user')}
    }).catch(explainError);
  }
}
if(window.apexAuth){
  window.apexAuth.onAuthStateChanged(user=>{
    const login=document.querySelector('#loginBtn');
    if(login)login.textContent=user?'Account: '+(user.email||'Google user'):'Log in / Sign up';
    const avatar=document.querySelector('.avatar');
    if(avatar)avatar.textContent=user?(user.email||'U').slice(0,1).toUpperCase():'U';
  });
}
$('#loginBtn').addEventListener('click',showAuthDialog);

let hideZeroWalletAssets=false;
function renderWallet(){
  const list=$('#walletAssetList'); if(!list) return;
  const user=window.apexAuth&&window.apexAuth.currentUser;
  const acct=$('#walletAccount');
  if(acct) acct.textContent=user?'Signed in: '+(user.email||'Google account'):'Not signed in · log in to manage account';
  const total=$('#walletTotal'); if(total) total.innerHTML='$0.00 <small>USD</small>';
  const walletAssets=assets.filter(a=>Number.isFinite(a.price)&&(!hideZeroWalletAssets));
  if(!walletAssets.length){list.innerHTML='<p class="disclaimer">Live asset prices are loading. Check your connection.</p>';return;}
  list.innerHTML=walletAssets.map(a=>`<div class="wallet-asset-row"><span class="wallet-asset-icon">${a.icon}</span><div class="wallet-asset-main"><b>${a.sym}</b><small>${a.name}</small></div><div class="wallet-asset-value"><b>0.000000</b><small>$0.00 · Price ${money(a.price)}</small></div></div>`).join('');
}
$('#refreshAssets')?.addEventListener('click',async()=>{await refreshMarket();renderWallet();toast('Asset prices refreshed')});
$('#hideZeroAssets')?.addEventListener('click',()=>{hideZeroWalletAssets=!hideZeroWalletAssets;$('#hideZeroAssets').textContent=hideZeroWalletAssets?'Show all assets ◉':'Hide zero balances ◉';renderWallet()});
if(window.apexAuth)window.apexAuth.onAuthStateChanged(()=>renderWallet());

draw();refreshMarket();setInterval(refreshMarket,15000);$('#orderType').dispatchEvent(new Event('change'));if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
// APEX account profile + Firebase Firestore/Storage backend.
const profileStoreKey=()=>{const u=window.apexAuth&&window.apexAuth.currentUser;return 'apex_profile_'+(u?u.uid:'guest')};
const profileDoc=()=>{const u=window.apexAuth&&window.apexAuth.currentUser;if(!u||!window.apexDb)throw new Error('Firebase database unavailable');return window.apexDb.collection('users').doc(u.uid)};
function makeUid(user){return user?'APX'+String(user.uid.replace(/[^a-z0-9]/gi,'').slice(-12)).toUpperCase().padStart(12,'0'):'Sign in required'}
async function loadProfile(){const user=window.apexAuth&&window.apexAuth.currentUser;const email=$('#profileEmail'),welcome=$('#profileWelcome'),uid=$('#profileUid');if(email)email.textContent=user?(user.email||'Google account'):'Sign in to manage your account';if(welcome)welcome.textContent=user?(user.displayName||'My Account'):'My Account';if(uid)uid.textContent=makeUid(user);const av=$('#profileAvatar');if(av)av.textContent=(user?(user.displayName||user.email||'U'):'U').slice(0,1).toUpperCase();if(!user)return;try{if(!window.apexDb)throw new Error('Firestore SDK unavailable');const snap=await profileDoc().get();const d=snap.exists?(snap.data().profile||{}):{};['profileName','profilePhone','profileCountry','profileDob','profileAddress'].forEach(id=>{const el=$('#'+id);if(el&&d[id]!==undefined)el.value=d[id]});if(d.profileName&&welcome)welcome.textContent=d.profileName;renderSavedProfile(d);if(snap.exists&&Object.keys(d).length){$('#profileEditPanel').hidden=true;$('#profileDetailsPanel').hidden=false}else{$('#profileEditPanel').hidden=false;$('#profileDetailsPanel').hidden=true}if($('#profileSaveStatus'))$('#profileSaveStatus').textContent=snap.exists?'Synced to account':'Not saved';const k=snap.exists?snap.data().kyc:null;if($('#kycStatus'))$('#kycStatus').textContent=k?(k.status||'Pending review'):'Not started';if(k&&$('#kycMessage'))$('#kycMessage').textContent='KYC request status: '+(k.status||'Pending review')+'. Uploaded documents are private to your account and available to authorised review processes.';}catch(e){console.warn('Cloud profile load failed',e);if($('#profileSaveStatus'))$('#profileSaveStatus').textContent='Cloud unavailable';}}
function renderSavedProfile(d){const labels={profileName:'savedProfileName',profilePhone:'savedProfilePhone',profileCountry:'savedProfileCountry',profileDob:'savedProfileDob',profileAddress:'savedProfileAddress'};Object.entries(labels).forEach(([key,id])=>{const el=$('#'+id);if(el)el.textContent=(d[key]||'').trim()||'Not set'});}
function profileDataFromForm(){const d={};['profileName','profilePhone','profileCountry','profileDob','profileAddress'].forEach(id=>d[id]=$('#'+id)?.value||'');return d}
$('#editProfileBtn')?.addEventListener('click',()=>{$('#profileDetailsPanel').hidden=true;$('#profileEditPanel').hidden=false});
document.querySelectorAll('[data-edit-field]').forEach(b=>b.addEventListener('click',()=>{const id=b.dataset.editField;$('#profileDetailsPanel').hidden=true;$('#profileEditPanel').hidden=false;const el=$('#'+id);if(el){el.focus();el.scrollIntoView({behavior:'smooth',block:'center'})}}));
$('#saveProfile')?.addEventListener('click',async()=>{const user=window.apexAuth&&window.apexAuth.currentUser;if(!user){toast('Please sign in first');showAuthDialog();return}const d={};['profileName','profilePhone','profileCountry','profileDob','profileAddress'].forEach(id=>d[id]=$('#'+id)?.value||'');try{if(!window.apexDb)throw new Error('Firestore SDK unavailable');await profileDoc().set({uid:user.uid,email:user.email||'',profile:d,updatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});$('#profileSaveStatus').textContent='Synced to account';if(d.profileName)$('#profileWelcome').textContent=d.profileName;renderSavedProfile(d);$('#profileEditPanel').hidden=true;$('#profileDetailsPanel').hidden=false;toast('Profile synced to your account')}catch(e){console.error(e);$('#profileSaveStatus').textContent='Cloud save failed';toast('Cloud save failed. Enable Firestore and deploy rules.')}});
$('#copyUid')?.addEventListener('click',async()=>{const t=$('#profileUid')?.textContent||'';try{await navigator.clipboard.writeText(t);toast('UID copied')}catch(e){toast(t)}});
$('#submitKyc')?.addEventListener('click',async()=>{
 const user=window.apexAuth&&window.apexAuth.currentUser;if(!user){toast('Please sign in first');showAuthDialog();return}
 const name=$('#profileName')?.value.trim()||'',doc=$('#kycDocNumber')?.value.trim()||'',front=$('#kycFront')?.files?.[0],selfie=$('#kycSelfie')?.files?.[0],back=$('#kycBack')?.files?.[0]||null;
 if(!name||!doc){toast('Enter full name and document number');return}if(!front||!selfie){toast('Choose document front and selfie images first');return}
 if(!window.apexDb||!window.apexStorage){toast('Firebase backend unavailable. Enable Firestore and Storage.');return}
 const maxBytes=8*1024*1024;for(const f of [front,back,selfie].filter(Boolean)){if(!f.type.startsWith('image/')){toast('Only image files are allowed');return}if(f.size>maxBytes){toast('Each image must be under 8 MB');return}}
 const btn=$('#submitKyc');if(btn){btn.disabled=true;btn.textContent='Uploading securely…'}
 try{
   const root=window.apexStorage.ref().child('kyc/'+user.uid);const upload=async(file,key)=>{const ref=root.child(key);await ref.put(file,{contentType:file.type,customMetadata:{ownerUid:user.uid}});return {path:ref.fullPath,contentType:file.type,size:file.size}};
   const docs={front:await upload(front,'front-'+Date.now()),selfie:await upload(selfie,'selfie-'+Date.now())};if(back)docs.back=await upload(back,'back-'+Date.now());
   await profileDoc().set({uid:user.uid,email:user.email||'',kyc:{status:'Pending review',documentType:$('#kycDocType')?.value||'CNIC',documentNumber:doc,legalName:name,documents:docs,submittedAt:firebase.firestore.FieldValue.serverTimestamp(),updatedAt:firebase.firestore.FieldValue.serverTimestamp()}},{merge:true});
   $('#kycStatus').textContent='Pending review';$('#kycMessage').textContent='Your request and documents were uploaded to private Firebase Storage and the request was saved. This is not identity approval; an authorised reviewer or compliant KYC provider must verify it.';toast('KYC request submitted for review');
 }catch(e){console.error('KYC backend upload failed',e);$('#kycMessage').textContent='Upload/submission failed: '+(e.code||e.message||'Firebase error')+'. Check Firebase Storage, Firestore and deployed security rules.';toast('KYC submission failed: '+(e.code||'check Firebase setup'))}
 finally{if(btn){btn.disabled=false;btn.textContent='Submit KYC request'}}
});
$('#changePassword')?.addEventListener('click',async()=>{const u=window.apexAuth&&window.apexAuth.currentUser;if(!u||!u.email){toast('Sign in with email first');return}try{await firebase.auth().sendPasswordResetEmail(u.email);toast('Password reset email sent')}catch(e){toast('Could not send reset email: '+(e.code||'error'))}});
$('#verifyEmail')?.addEventListener('click',async()=>{const u=window.apexAuth&&window.apexAuth.currentUser;if(!u){toast('Please sign in first');return}try{await u.sendEmailVerification();toast('Verification email sent')}catch(e){toast('Could not send verification: '+(e.code||'error'))}});
$('#signOutProfile')?.addEventListener('click',async()=>{const u=window.apexAuth;if(!u){toast('Authentication unavailable');return}try{await u.signOut();loadProfile();toast('Signed out')}catch(e){toast('Sign out failed')}});
$('#profileHelp')?.addEventListener('click',()=>toast('Support channel must be configured by APEX admin'));$('#profileAbout')?.addEventListener('click',()=>toast('APEX Exchange preview'));if(window.apexAuth)window.apexAuth.onAuthStateChanged(()=>loadProfile());loadProfile();

// Top-right avatar opens the full profile page.
$('#topProfileBtn')?.addEventListener('click',()=>{tab('profile');loadProfile();});
