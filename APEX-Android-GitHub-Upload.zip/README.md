# APEX Exchange — Android source prototype

This project packages the APEX mobile-first web interface in an Android WebView.

## Included in this iteration
- Binance public 24-hour ticker API refresh (15-second polling)
- Public kline chart API with 1m, 15m, 1h, 4h, and 1d intervals
- Select a market row to switch the trading pair
- Search and gainers/losers market filters
- Market/Limit/Stop-limit selector UI and estimated total calculation
- No fabricated account balance; private account screens remain explicitly disconnected
- Android WebView asset loader and Internet permission

## Build Android APK
1. Open this `apex-android` folder in Android Studio on a computer with Android SDK 35 installed.
2. Allow Gradle sync.
3. Select **Build > Build APK(s)** for a test APK, or **Build > Generate Signed Bundle / APK** for a release build.

This runtime does not contain Android SDK/Gradle build tools, so an APK binary could not be compiled or tested here. The included files are Android source, not an installable APK.

## Binance connection boundary
Only public market data is implemented. There is no Binance account login, private balance endpoint, real order placement, deposits, or withdrawals. Do not place API keys or secrets in the app. A next phase should add a server-side integration tested against Binance Spot Testnet, with API-key permission restrictions, authentication, request signing on the server, rate limits, order validation, audit logs, and explicit risk controls. Withdrawals should remain disabled.


## Firebase Authentication setup (important)
- This archive includes `app/google-services.json` for package `com.apex.exchange` and Firebase Web SDK compat initialization in the Android WebView page.
- In Firebase Console, enable Email/Password and Google under Authentication → Sign-in method.
- In Authentication → Settings → Authorized domains, add `appassets.androidplatform.net` if Firebase reports `auth/unauthorized-domain`. For the website, also add its actual hosted domain.
- Google OAuth sign-in in an Android WebView can be restricted by Google. If redirect sign-in is blocked, a native Google sign-in integration or opening OAuth in the system browser may be needed.
- Authentication only identifies users. This prototype still has no real trading, deposit, withdrawal, custody, or account-balance backend.


## Auth fix update
- Fixed a recursive error-message handler that could leave email/password sign-in stuck at “Please wait…” after an authentication error.
- Added a Sign out button in the account dialog when a Firebase user is signed in.
- This is a source update; build and test a fresh APK before relying on it.


## Wallet / Assets preview
- Assets tab now displays a wallet-style list of supported coins and live Binance market prices when available.
- Balances intentionally show zero because there is no secure user balance ledger or exchange backend connected.
- Deposit, withdrawal, and transfer actions remain unavailable; do not use this UI to imply real funds are held.
- This is a source ZIP, not a tested APK. Build in GitHub Actions and test before release.


## Profile & KYC preview
This build adds editable profile fields, a deterministic UID derived from Firebase Auth UID, password-reset/email-verification actions, and a local KYC draft/status UI. Profile fields and KYC draft status are stored in local device storage only. ID images are not uploaded. This is NOT a production KYC system and does not verify identity, sync profile details across devices, or authorize deposits/withdrawals/trading. Before production, implement authenticated Firestore/SQL profile storage with strict per-user access rules, secure document storage, audit logs, rate limits, and a compliant KYC provider with real review workflow. Never use a client-only status as proof of verification.
