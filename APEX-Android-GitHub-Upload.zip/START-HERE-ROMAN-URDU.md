# APEX Exchange — Agla Step (Roman Urdu)

## Is ZIP mein kya hai?
- `apex-android/`: tumhara existing Android app source, unchanged.
- `backend/`: safer Testnet account-check backend starter.

## Zaroori sach
- Android app ka existing Buy/Sell button abhi backend se connected nahi hai.
- Backend `/api/account` se Binance Spot Testnet account check kar sakta hai.
- `/api/order` jaan-boojh kar disabled hai. Public unauthenticated trading endpoint banana unsafe hai. Pehle user authentication, rate limits, input/order filters, audit logging, and user ownership checks chahiye.
- Is ZIP mein API Key/Secret nahi hain. Keys source code ya app ke andar kabhi na daalein.
- Ye package khud se cloud par deploy nahi hota aur APK bhi nahi hai.

## GitHub Codespaces secrets
GitHub repository → Settings → Secrets and variables → Codespaces:
- `BINANCE_TESTNET_API_KEY` = sirf Testnet HMAC API key ki value
- `BINANCE_TESTNET_API_SECRET` = sirf usi key-pair ka secret

Secret ko `API Key:` jaisay label ke saath na paste karein. API Secret dobara dekhne/verify karne ke liye share na karein. Agar key invalid ho, Binance Spot Testnet par ek HMAC-SHA-256 key-pair banayein aur dono values privately save karein, phir dono GitHub secrets update karein.

## Local/Codespaces run
Backend folder mein:
1. `npm install`
2. `npm start`
3. Port 3000 ko browser mein open karein. `/` par `configured: true` expected hai.
4. `/api/account` khol kar account response check karein.

Agar `EADDRINUSE` aaye to port 3000 par server pehle se chal raha ho sakta hai; second server start na karein.

## Production warning
Is backend ko public host karne se pehle CORS ko specific app domain tak limit karein, authentication add karein, abuse/rate limits add karein, and deploy logs/secrets access review karein. Sirf Testnet use karein. Real Binance keys/funds use na karein.

## Buy/Sell Testnet UI update
The Android web UI now includes a TESTNET-only order submission flow for Market and Limit orders. It prompts for the deployed HTTPS backend URL and posts orders to `/api/order`. It does NOT enable real Binance trading. The backend must be deployed, its API secrets must be set as host environment variables, and `/api/account` must be verified before placing test orders. Do not put API secrets into this ZIP or the app.
